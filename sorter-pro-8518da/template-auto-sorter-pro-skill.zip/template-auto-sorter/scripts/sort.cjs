#!/usr/bin/env node
/* Template Auto-Sorter, headless.
   Uses the same sorting rules as the web app (app/classify.js) and prints the sorted library.

   node sort.cjs --demo [--out DIR]
       Sorted sample library (Hall Of Templates "1000 Templates List 3"). No token, no network.
   node sort.cjs <figma file link> [more links] [--token-file PATH] [--out DIR] [--thumbs N]
       Sorts your own Figma file. More than one link (all files in one report) is Pro. The token is read from FIGMA_TOKEN or from --token-file
       (default ~/.figma-token). It is only ever sent to https://api.figma.com and never printed.

   Writes sorted.json and sorted.html (or sorted-sample.html for --demo) into --out (default: current folder). */
'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');

const HERE = __dirname;
const APP = path.join(HERE, '..', 'app');
const HOSTED = 'https://dieginmachin.github.io/template-auto-sorter/';
const TAS = require(path.join(APP, 'classify.js'));
// Pro skill builds ship app/pro-local.js (see build-pro.sh). Free builds do not.
const PRO = fs.existsSync(path.join(APP, 'pro-local.js'));
const TOOLS = 'https://halloftemplates.com/sorter-pro';

function arg(name, def) { const i = process.argv.indexOf(name); return i > -1 ? process.argv[i + 1] : def; }
const has = (name) => process.argv.includes(name);
const OUT = path.resolve(arg('--out', '.'));

/* ---------- Figma REST (same calls as app/figma.js) ---------- */
function readToken() {
  if (process.env.FIGMA_TOKEN) return process.env.FIGMA_TOKEN.trim();
  const f = arg('--token-file', path.join(os.homedir(), '.figma-token'));
  try { return fs.readFileSync(f.replace(/^~/, os.homedir()), 'utf8').trim(); } catch (e) { return ''; }
}
function parseUrl(u) {
  const s = String(u || '').trim();
  if (/^[0-9a-zA-Z]{22,128}$/.test(s)) return { key: s };
  const m = s.match(/figma\.com\/(?:design|file|proto)\/([0-9a-zA-Z]{22,128})(?:\/branch\/([0-9a-zA-Z]{22,128}))?/);
  return m ? { key: m[2] || m[1] } : null;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function get(token, p, tries = 0) {
  let res;
  try { res = await fetch('https://api.figma.com/v1' + p, { headers: { 'X-Figma-Token': token } }); }
  catch (e) { const err = new Error('Could not reach api.figma.com from here (' + (e.cause && e.cause.code || e.message) + ').'); err.code = 'network'; throw err; }
  if (res.ok) return res.json();
  let body = {}; try { body = await res.json(); } catch (e) {}
  const msg = body.err || body.message || res.statusText;
  if (res.status === 429 && tries < 4) { const w = +(res.headers.get('retry-after') || 5); if (w <= 120) { console.error('Figma asked to wait ' + w + 's...'); await sleep(w * 1000 + 250); return get(token, p, tries + 1); } }
  if (res.status >= 500 && tries < 2) { await sleep(1500 * (tries + 1)); return get(token, p, tries + 1); }
  const err = new Error(res.status === 403 ? (/token/i.test(msg) ? 'Figma did not accept that token. Make a new one with "File content: read" access.' : 'This token cannot open that file. The account that owns the token must be able to view it.')
    : res.status === 404 ? 'Figma could not find that file. Check the link.' : 'Figma said: ' + msg);
  err.code = 'http' + res.status; throw err;
}
async function loadFile(token, key) {
  console.error('Reading the file structure...');
  const file = await get(token, '/files/' + key + '?depth=4');
  const res = TAS.collect(file, key);
  let items = res.items, pending = res.pending, rounds = 0;
  while (pending.length && rounds < 3) {
    rounds++;
    const batch = pending.splice(0, pending.length); let next = [];
    for (let i = 0; i < batch.length; i += 40) {
      const part = batch.slice(i, i + 40);
      console.error('Opening nested sections...');
      const nodes = await get(token, '/files/' + key + '/nodes?depth=2&ids=' + encodeURIComponent(part.map((p) => p.id).join(',')));
      part.forEach((p) => {
        const doc = nodes.nodes && nodes.nodes[p.id] && nodes.nodes[p.id].document;
        if (!doc) return;
        if (p.self && !TAS.hasComponents(doc)) { items.push(TAS.classifyPart(doc, Object.assign({}, p.ctx, { group: p.pgroup }))); return; }
        if (!doc.children) return;
        const sub = TAS.collect({ name: file.name, document: { children: [{ name: p.ctx.page, children: [] }] } }, key);
        items = items.concat(sub.walk(doc.children, Object.assign({}, p.ctx, { container: p.name })));
        next = next.concat(sub.pending);
      });
    }
    pending = next;
  }
  TAS.finalize(items);
  return { key, name: file.name, lastModified: file.lastModified, items };
}
async function thumbs(token, key, ids) {
  const out = {};
  for (let i = 0; i < ids.length; i += 60) {
    const part = ids.slice(i, i + 60);
    console.error('Rendering thumbnails ' + (i + 1) + '-' + (i + part.length) + ' of ' + ids.length + '...');
    try { const r = await get(token, '/images/' + key + '?scale=0.34&format=jpg&ids=' + encodeURIComponent(part.join(','))); Object.assign(out, r.images || {}); }
    catch (e) { console.error('Thumbnails stopped: ' + e.message); break; }
  }
  return out;
}

/* ---------- report ---------- */
function count(list, f) { const c = {}; list.forEach((x) => { const v = f(x); (Array.isArray(v) ? v : [v]).forEach((k) => { if (k) c[k] = (c[k] || 0) + 1; }); }); return Object.entries(c).sort((a, b) => b[1] - a[1]); }
function line(title, entries, max = 12) { return '**' + title + '**: ' + entries.slice(0, max).map(([k, n]) => k + ' ' + n).join(' · ') + (entries.length > max ? ' · +' + (entries.length - max) + ' more' : ''); }
function summary(data, parts, multi) {
  const emails = data.items.filter((i) => i.kind === 'email');
  const p = parts || data.items.filter((i) => i.kind === 'part');
  const out = ['## ' + data.name, '', emails.length + ' emails' + (p.length ? ', ' + p.length + ' parts' : '') + ' sorted.', ''];
  if (emails.length) {
    if (multi) out.push(line('File', count(emails, (i) => i.fileName)), '');
    out.push(line('Brand', count(emails, (i) => i.brand)), '', line('Flow or campaign', count(emails, (i) => i.type)), '', line('Category', count(emails, (i) => i.category)), '',
      line('Signature section', count(emails, (i) => i.signature)), '', line('Language', count(emails, (i) => i.lang)), '', line('Year', count(emails, (i) => i.year)), '', line('Length', count(emails, (i) => i.length)));
  }
  if (p.length) out.push('', line('Parts by level', count(p, (i) => i.level)), '', line('Parts by type', count(p, (i) => i.part)));
  if (!emails.length && !p.length) out.push('No email frames found. The sorter looks for frames 320 to 900px wide that are at least 0.75x as tall as they are wide. See ' + HOSTED + 'help.html');
  return out.join('\n');
}
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function html(data, thumbOf, linkOf, note) {
  const emails = data.items.filter((i) => i.kind === 'email');
  const brands = count(emails, (i) => i.brand).map(([b]) => b);
  const sec = brands.map((b) => {
    const list = emails.filter((i) => i.brand === b);
    const cats = count(list, (i) => i.category).map(([c]) => c);
    return '<section><h2>' + esc(b) + ' <small>' + list.length + '</small></h2>' + cats.map((c) => {
      const l = list.filter((i) => i.category === c);
      return '<h3>' + esc(c) + ' <small>' + l.length + '</small></h3><div class="row">' + l.map((i) => {
        const t = thumbOf(i);
        return '<a class="card" href="' + esc(linkOf(i)) + '" target="_blank" rel="noopener">' + (t ? '<img loading="lazy" src="' + esc(t) + '" alt="" onerror="this.remove()">' : '') +
          '<b>' + esc(i.title || i.name) + '</b><span>' + esc([i.type, i.signature, i.lang, i.year, i.length].filter(Boolean).join(' · ')) + '</span></a>';
      }).join('') + '</div>';
    }).join('') + '</section>';
  }).join('');
  return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + esc(data.name) + ' · sorted</title><style>' +
    ':root{--bg:#f2efe9;--ink:#161614;--mute:#86837c;--line:#d9d4ca;--card:#fff}@media (prefers-color-scheme:dark){:root{--bg:#161614;--ink:#f2efe9;--mute:#a19d94;--line:#34322e;--card:#22211f}}' +
    'body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 system-ui,-apple-system,sans-serif}header{padding:28px 16px 8px;max-width:1200px;margin:auto}h1{font:400 30px/1.15 Georgia,serif;margin:0 0 6px}p{color:var(--mute);margin:0}' +
    'main{max-width:1200px;margin:auto;padding:0 16px 48px}h2{font:500 20px Georgia,serif;margin:36px 0 4px;border-top:1px solid var(--line);padding-top:16px}h3{font:500 12px ui-monospace,monospace;letter-spacing:.06em;text-transform:uppercase;color:var(--mute);margin:16px 0 8px}small{color:var(--mute);font-weight:400}' +
    '.row{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:8px;color:inherit;text-decoration:none;display:flex;flex-direction:column;gap:4px}' +
    '.card img{width:100%;height:190px;object-fit:cover;object-position:top;border-radius:4px;background:var(--line)}.card b{font-weight:500;font-size:13px}.card span{color:var(--mute);font-size:11px}</style></head><body>' +
    '<header><h1>' + esc(data.name) + '</h1><p>' + emails.length + ' emails sorted by brand, then category. ' + esc(note || '') + '</p></header><main>' + sec + '</main></body></html>';
}

/* ---------- Figma connector (no token): get_metadata XML -> Figma-like nodes ---------- */
function fromMetadata(xml) {
  const root = { children: [] }, stack = [root];
  const re = /<(\/?)([a-z_-]+)((?:\s+[a-zA-Z-]+="[^"]*")*)\s*(\/?)>/g;
  const dec = (s) => s.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  let m;
  while ((m = re.exec(xml))) {
    if (m[1]) { if (stack.length > 1) stack.pop(); continue; }
    const a = {}; m[3].replace(/([a-zA-Z-]+)="([^"]*)"/g, (_, k, v) => { a[k] = dec(v); });
    const tag = m[2].toUpperCase().replace(/-/g, '_');
    const n = { id: a.id, name: a.name || '', type: tag === 'CANVAS' || tag === 'PAGE' ? 'CANVAS' : tag, children: [],
      absoluteBoundingBox: { x: +a.x || 0, y: +a.y || 0, width: +a.width || 0, height: +a.height || 0 } };
    if (a.hidden === 'true' || a.visible === 'false') n.visible = false;
    stack[stack.length - 1].children.push(n);
    if (!m[4]) stack.push(n);
  }
  return root.children.filter((n) => n.type === 'CANVAS');
}

(async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  const meta = arg('--metadata');
  if (meta) {
    // node sort.cjs --metadata pages.xml --key FILEKEY --name "File name": one or more get_metadata page dumps, concatenated
    const key = (parseUrl(arg('--key', '')) || {}).key || 'connector';
    const pages = fromMetadata(fs.readFileSync(meta, 'utf8'));
    const res = TAS.collect({ name: arg('--name', 'Figma file'), document: { children: pages } }, key);
    if (res.pending.length) console.error(res.pending.length + ' deeply nested sections were not opened; pass their get_metadata output too for a full sort.');
    TAS.finalize(res.items);
    const data = { key, name: arg('--name', 'Figma file'), items: res.items };
    fs.writeFileSync(path.join(OUT, 'sorted.json'), JSON.stringify(data, null, 1));
    const file = path.join(OUT, 'sorted.html');
    fs.writeFileSync(file, html(data, () => null, (i) => 'https://www.figma.com/design/' + key + '/?node-id=' + encodeURIComponent(String(i.id).replace(/:/g, '-')), 'Read through the Figma connector. Click a card to open the frame in Figma.'));
    console.log(summary(data));
    console.log('\nReport: ' + file + '\nData: ' + path.join(OUT, 'sorted.json'));
    return;
  }
  if (has('--demo')) {
    const src = fs.readFileSync(path.join(APP, 'media', 'demo', 'demo.js'), 'utf8');
    const D = JSON.parse(src.slice(src.indexOf('{'), src.lastIndexOf('}') + 1));
    const base = arg('--thumb-base', HOSTED);
    const file = path.join(OUT, 'sorted-sample.html');
    fs.writeFileSync(file, html(D.data, (i) => base + 'media/demo/t/' + String(i.id).replace(/:/g, '-') + '.jpg', () => HOSTED + 'demo.html',
      'Sample library from Hall Of Templates, sorted ahead of time. Live version: ' + HOSTED + 'demo.html'));
    console.log(summary(D.data, D.parts));
    console.log('\nReport: ' + file);
    return;
  }
  const targets = process.argv.slice(2).filter((a, i, all) => !a.startsWith('--') && !(all[i - 1] || '').startsWith('--'));
  const keys = [...new Set(targets.map((t) => (parseUrl(t) || {}).key).filter(Boolean))];
  if (!keys.length) { console.error('Usage: node sort.cjs --demo | node sort.cjs <figma file link> [more links, Pro]'); process.exit(2); }
  if (keys.length > 1 && !PRO) {
    console.error('Free sorts one file at a time. Sorting ' + keys.length + ' files on one canvas is Pro.\n' +
      'Pro runs locally in this skill for $29 (Tools): ' + TOOLS + '\nSort them one by one for now, or run this again with one link.');
    process.exit(5);
  }
  const token = readToken();
  if (!token) { console.error('No Figma token. Set FIGMA_TOKEN or save it to ~/.figma-token (one line).'); process.exit(3); }
  try {
    const sets = [];
    for (const key of keys) {
      if (keys.length > 1) console.error('File ' + (sets.length + 1) + ' of ' + keys.length + '...');
      sets.push(await loadFile(token, key));
    }
    const data = sets.length === 1 ? sets[0] : { key: keys.join(','), name: sets.length + ' files: ' + sets.map((d) => d.name).join(', '), items: [].concat(...sets.map((d) => d.items)) };
    const n = Math.min(+arg('--thumbs', 120) || 0, 500);
    const imgs = {};
    const per = Math.max(1, Math.floor(n / sets.length));
    if (n) for (const d of sets) Object.assign(imgs, await thumbs(token, d.key, d.items.filter((i) => i.kind === 'email').slice(0, per).map((i) => i.id)));
    const keyOf = (i) => i.file || keys[0];
    fs.writeFileSync(path.join(OUT, 'sorted.json'), JSON.stringify(sets.length === 1 ? data : { files: sets.map((d) => ({ key: d.key, name: d.name })), ...data }, null, 1));
    const file = path.join(OUT, 'sorted.html');
    fs.writeFileSync(file, html(data, (i) => imgs[i.id], (i) => 'https://www.figma.com/design/' + keyOf(i) + '/?node-id=' + encodeURIComponent(String(i.id).replace(/:/g, '-')),
      'Click a card to open the frame in Figma. Thumbnail links from Figma expire after about 30 days.'));
    console.log(summary(data, null, sets.length > 1));
    console.log('\nReport: ' + file + '\nData: ' + path.join(OUT, 'sorted.json'));
  } catch (e) { console.error(e.message); process.exit(e.code === 'network' ? 4 : 1); }
})();
