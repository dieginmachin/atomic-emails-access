#!/usr/bin/env bash
# Template Auto-Sorter: serve the app from this skill on localhost and open it in the browser.
#   start.sh            serve and open the sorted sample (demo.html)
#   start.sh app        serve and open the app (index.html), where you connect your own Figma file
#   start.sh stop       stop the local server
#   NO_OPEN=1 start.sh  serve only, print the link
set -u
DIR="$(cd "$(dirname "$0")/.." && pwd)"
APP="$DIR/app"
STATE="${TMPDIR:-/tmp}/template-auto-sorter"
mkdir -p "$STATE"
PIDF="$STATE/server.pid"; PORTF="$STATE/server.port"

stop() { [ -f "$PIDF" ] && kill "$(cat "$PIDF")" 2>/dev/null; rm -f "$PIDF" "$PORTF"; }
if [ "${1:-}" = "stop" ]; then stop; echo "Auto-Sorter server stopped."; exit 0; fi

up() { [ -f "$PIDF" ] && [ -f "$PORTF" ] && kill -0 "$(cat "$PIDF")" 2>/dev/null && curl -fs -o /dev/null "http://127.0.0.1:$(cat "$PORTF")/demo.html"; }

if ! up; then
  stop
  PORT=""
  for p in 8765 8766 8767 8768 8769 8770 8771 8772; do
    if ! (exec 3<>"/dev/tcp/127.0.0.1/$p") 2>/dev/null; then PORT=$p; break; fi
  done
  [ -z "$PORT" ] && { echo "No free port between 8765 and 8772." >&2; exit 1; }
  if command -v python3 >/dev/null 2>&1; then
    nohup python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$APP" >"$STATE/server.log" 2>&1 &
  elif command -v node >/dev/null 2>&1; then
    nohup node "$DIR/scripts/serve.cjs" "$PORT" "$APP" >"$STATE/server.log" 2>&1 &
  else
    echo "Needs python3 or node to serve the app locally. Use the hosted app instead: https://dieginmachin.github.io/template-auto-sorter/" >&2; exit 1
  fi
  echo $! >"$PIDF"; echo "$PORT" >"$PORTF"
  for i in $(seq 1 30); do up && break; sleep 0.2; done
  up || { echo "The local server did not start. Log: $STATE/server.log" >&2; exit 1; }
fi

PORT="$(cat "$PORTF")"
PAGE="demo.html"; [ "${1:-}" = "app" ] && PAGE=""
URL="http://127.0.0.1:$PORT/$PAGE"
if [ -z "${NO_OPEN:-}" ]; then
  if command -v open >/dev/null 2>&1; then open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL" >/dev/null 2>&1
  elif command -v cmd.exe >/dev/null 2>&1; then cmd.exe /c start "" "$URL"
  fi
fi
echo "$URL"
