# Template Auto-Sorter Pro for Claude

Your Pro version of the Auto-Sorter skill (Auto-Sorter Tools). Same sorter, with Pro already on: every template file on one canvas and the Parts library. Read-only: it never changes your Figma files.

It replaces the free skill if you have it (same name, same folder).

## Claude Code (full app, runs on your computer)

Unzip this file into `~/.claude/skills/` (you should end up with `~/.claude/skills/template-auto-sorter/SKILL.md`), open Claude Code and type `/template-auto-sorter`.

From the Terminal, if the zip is in your Downloads folder:

```
unzip -oq ~/Downloads/template-auto-sorter-pro-skill.zip -d ~/.claude/skills && claude "/template-auto-sorter"
```

## Claude app (claude.ai, desktop or web)

1. Settings, Capabilities: turn on code execution and file creation.
2. Settings, Capabilities, Skills: upload this zip (remove the free Auto-Sorter skill first if you added it).
3. In a new chat, type: `Run the Auto-Sorter`.

## What you need for your own files

- The Figma file links.
- Easiest: have the Figma connector on in Claude (sign in once, no token).
- For the full visual canvas and Parts, a Figma personal access token: in Figma, avatar menu, Settings, Security, Personal access tokens, Generate new token, scope "File content: Read only". Paste it into the app page, not into a chat.

Your Pro key (in your receipt email) is still what unlocks Pro in the hosted app on other computers.

Help: https://dieginmachin.github.io/template-auto-sorter/help.html
Questions: diego@halloftemplates.com

## The workshop

Want to watch the whole method on a real library? The recorded Auto-Sorter workshop (with workbook and slides) is $68 for Tools owners instead of $97. Reply to your receipt email or write to diego@halloftemplates.com. Details: https://halloftemplates.com/sorter-pro

## Atomize your emails

Breaking every email into parts happens in your Figma file, with Claude: that is Atomic Emails ($17), the workshop plus the atomic-extractor skill. It builds a Parts page the sorter reads in Parts mode. https://www.halloftemplates.com/sales-atomic-emails-ai-17--e2760
