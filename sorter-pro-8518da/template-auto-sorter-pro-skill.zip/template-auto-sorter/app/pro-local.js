/* Auto-Sorter Pro skill: Pro is on in this local copy (no key needed). Loaded before pro.js. */
try { localStorage.setItem('tas:v1:pro', 'cdb0ff681ff8fd6c54833e8a4331c7ff4755698b06063f7ef1ecfb6e6d29a639'); } catch (e) {}
