---
name: atomic-extractor
description: Break approved email designs in Figma into Atomic Emails parts (organisms, molecules, atoms) and build a Parts page of reusable components, laid out like the Template Auto-Sorter. Use when someone says "atomize", "extract parts", "break this email into sections", "build a parts library", "Atomic Emails extractor", or shares a Figma file of emails and wants reusable sections, cards and buttons from it. Needs the Figma connector (Figma MCP).
---

# Atomic Emails extractor

Turns finished emails into a parts library, the core step of the Atomic Emails method: **Elements → Containers → Sections** (atoms → molecules → organisms). AI drafts, the designer approves. The skill never edits the source emails. It clones parts onto a page called **Parts**, turns each one into a component, and groups them by type the same way the Template Auto-Sorter shows them.

## What becomes what

| In the email | Level | Example names |
|---|---|---|
| A full-width row (Emailify 🚣 Row, or any full-width child of the email). 🎁 wrappers are opened; whole headers and footers stay whole | **Organism** (section) | Hero, Product grid, Reviews, Footer, Text & CTA, Image gallery |
| A column inside a row that has two or more columns (Emailify 🏛️ Column) | **Molecule** (container) | Card (image, text, button), Image + text, Text + button |
| Buttons (🔗), tags and badges, logos, social icon rows | **Atom** (element) | Button / Shop now, Badge, Logo |

Identical parts (same name, size, layer structure and text) collapse into one. Each component's description says which email it came from and how many emails use it, and the most-used parts come first. Each type keeps at most `maxPerType` parts (24 by default) so the page stays light.

## Workflow

1. **Get the file and the scope.** Ask for the Figma file link if you don't have it. Ask which emails to atomize: a Figma Section (one brand), a page, or the current selection. Big files: go one brand section at a time.
2. **Say what will change, and get a yes before writing.** The skill adds or extends a page named **Parts** in that file and adds components there. The emails themselves are not touched. On a Figma Starter plan a file can have only 3 pages; if the file already has 3 and none is called Parts, ask which page to use (set `partsPage`) or suggest a duplicate of the file.
3. **Start a Figma session.** Call `create_session` with the file key, then load the `figma-use` skill before any `use_figma` call (pass `skillNames: "atomic-extractor,figma-use"`).
4. **Dry run first.** Send `scripts/extract.figma.js` through `use_figma` with `dryRun: true` and the chosen `source`. It returns how many emails it found, how many parts, how many are unique, and the count per level and type. Show the designer those numbers.
5. **Extract.** Run the same script with `dryRun: false`. Run it once per brand section. Re-runs add new groups to the existing Atoms / Molecules / Organisms sections.
6. **Check.** Take one `get_screenshot` of the Parts page and look for empty groups or parts that clearly aren't sections (stray decorations, tiny images). Delete those with a small `use_figma` call if the designer agrees.
7. **Hand off.** Tell the designer:
   - what was extracted (numbers per level, the most-reused parts);
   - that every part is now a component they can drop into new emails;
   - that the Template Auto-Sorter (https://dieginmachin.github.io/template-auto-sorter/) shows the Parts page in **Parts** mode after **Files → Re-sort from Figma**.

## The script

`scripts/extract.figma.js` is plain Figma Plugin API code. Edit only the `CONFIG` block at the top:

```js
const CONFIG = {
  source: 'section:Acme Co', // 'selection' | 'section:<name>' | 'page:<name>' | ['12:34', '12:35']
  partsPage: 'Parts',
  levels: ['Organisms', 'Molecules', 'Atoms'],
  maxPerType: 24,
  dryRun: true
};
```

Send the whole file as the `code` argument of `use_figma`. It returns a JSON summary (and `createdNodeIds` when it writes).

## Output contract (what the Auto-Sorter reads)

- Page **Parts** → sections **Organisms**, **Molecules**, **Atoms**.
- In each section, one dashed group per type (a label like `HERO   12` and a grid of components).
- Components are named `Type / Brand NN` (organisms and molecules) or `Button / <label>` (atoms).

The Template Auto-Sorter's Parts mode reads this structure exactly. Its **Atomize emails** button does the same breakdown read-only, without writing anything to Figma.

## Rules

- Never modify, move or delete the source emails.
- Always dry-run and get a yes before writing.
- If `use_figma` fails partway through, read the Parts page before running again, so you don't make duplicates.
- Keep the designer in the loop: the parts are a draft until they approve them.
