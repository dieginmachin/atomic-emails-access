# Install the Atomic Emails extractor

You need Claude with the **Figma connector** turned on (it's what lets Claude read and build in your Figma files).

## Claude desktop app or claude.ai

1. Download `atomic-extractor.zip` from the course lesson. Keep it zipped.
2. In Claude, open **Settings → Capabilities**, find **Skills**, and click **Upload skill**. Choose the zip.
3. Make sure the skill's switch is on.
4. In **Settings → Connectors**, connect **Figma** if it isn't already.

## Claude Code

Unzip it into your skills folder, so the file sits at `~/.claude/skills/atomic-extractor/SKILL.md`, and connect the Figma MCP server.

## Use it

Open a new chat and paste your Figma file link with a request like:

> Atomize the "Acme Co" section of https://www.figma.com/design/… into a parts library.

Claude first does a dry run and tells you how many organisms, molecules and atoms it found. Nothing is written until you say yes. Then it adds a **Parts** page with every part as a component, grouped by type. Your emails stay exactly as they were.

To browse the result, open the Template Auto-Sorter, then **Files → Re-sort from Figma**, then switch to **Parts**.
